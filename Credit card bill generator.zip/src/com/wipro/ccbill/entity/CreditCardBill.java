package com.wipro.ccbill.entity;


import java.util.Date;

import com.wipro.ccbill.exception.InputValidationException;

public class CreditCardBill {
	private String creditCardNo;
	private String customerId;
	@SuppressWarnings("unused")
	private Date billDate;
	private Transaction monthTransactions[];
	public CreditCardBill (){
		}
	public CreditCardBill(String creditCardNo, String customerId,
			Date billDate, Transaction[] monthTransactions) {
		this.creditCardNo = creditCardNo;
		this.customerId = customerId;
		this.billDate = billDate;
		this.monthTransactions = monthTransactions;
	}
	public double getTotalAmount(String transactionType)
	{
		double result=0,totalamount=0;
		if(!(transactionType.equals("DB")||transactionType.equals("CR")))
		{
			return 0.0;
		}
		else 
		{
			for(int i=0;i<monthTransactions.length;i++)
			{
				Transaction t=monthTransactions[i];
				if(transactionType.equals(t.getTransactionType()))
				totalamount+=t.getTransactionAmount();
				result=totalamount;
			}
		}	
		return result;
	}
	public double calculateBillAmount()
	{
		double result = 0;
		try
		{
			double totalamountspend = 0,totalamountpaid = 0,outstandingamount,Interestcalculated,billamount;  
			String k=validateData();
			if(k.equals("valid"))
			{
				if(monthTransactions.length>0&&monthTransactions.length!=0)
				{
					totalamountspend=getTotalAmount("DB");
					totalamountpaid=getTotalAmount("CR");
					outstandingamount=Math.abs(totalamountspend-totalamountpaid);
					Interestcalculated =((outstandingamount*0.199)/12);
					billamount=Interestcalculated+outstandingamount;
					result=billamount;
				}
				else
					result=0.0;
			}
		}
		catch(InputValidationException e)
		{
			result=0.0;
		}
		return result;
	}
	public String validateData() throws InputValidationException
	{
		String result;
		try
		{
			if((creditCardNo.equals(" "))||(creditCardNo.length()!=16)||(customerId.equals(" "))||(customerId.length()<6))
			{
				throw new InputValidationException();
			}
			else
				result="valid";
		}
		finally
		{}
		return result;
	}
}